import 'server-only'

import { createClient } from '@/lib/supabase/server'

export type AiUsageFeature =
  | 'chat'
  | 'summary'
  | 'flashcards'
  | 'quiz'
  | 'study_session'

const DEFAULT_DAILY_TOKEN_LIMIT = 100_000

export type AiUsageStatus = {
  tokensUsed: number
  tokenLimit: number
  hasUserOpenRouterKey: boolean
  resetsAt: string
}

type AiUsageRow = {
  id: string
  tokens_used: number | null
  created_at: string
}

export class AiUsageLimitError extends Error {
  constructor(limit: number, tokensUsedToday: number) {
    super(
      `Daily AI token limit reached (${tokensUsedToday.toLocaleString()} / ${limit.toLocaleString()} tokens). Add your own OpenRouter key in settings or try again tomorrow.`,
    )
    this.name = 'AiUsageLimitError'
    this.limit = limit
    this.tokensUsedToday = tokensUsedToday
  }

  limit: number
  tokensUsedToday: number
}

function getDailyTokenLimit() {
  const value = Number(process.env.APP_AI_DAILY_TOKEN_LIMIT)

  if (!Number.isFinite(value) || value <= 0) {
    return DEFAULT_DAILY_TOKEN_LIMIT
  }

  return Math.floor(value)
}

function getUsageWindow() {
  const now = new Date()
  const dayStart = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()),
  )
  const nextDayStart = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1),
  )

  return {
    dayStart: dayStart.toISOString(),
    nextDayStart: nextDayStart.toISOString(),
  }
}

function isInUsageWindow(createdAt: string, dayStart: string, nextDayStart: string) {
  const createdTime = new Date(createdAt).getTime()

  return (
    createdTime >= new Date(dayStart).getTime() &&
    createdTime < new Date(nextDayStart).getTime()
  )
}

async function getCurrentUser() {
  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    throw new Error('Unauthorized')
  }

  return { supabase, user }
}

export async function getCurrentAiUsageStatus(): Promise<AiUsageStatus> {
  const { supabase, user } = await getCurrentUser()
  const limit = getDailyTokenLimit()
  const { dayStart, nextDayStart } = getUsageWindow()
  const { data, error } = await supabase
    .from('ai_usage')
    .select('id, tokens_used, created_at')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (error) {
    throw new Error(error.message)
  }

  const usageRow = data as AiUsageRow | null
  const tokensUsedToday =
    usageRow && isInUsageWindow(usageRow.created_at, dayStart, nextDayStart)
      ? usageRow.tokens_used ?? 0
      : 0

  const { data: apiKey, error: apiKeyError } = await supabase
    .from('user_api_keys')
    .select('id')
    .eq('user_id', user.id)
    .eq('provider', 'openrouter')
    .eq('is_active', true)
    .limit(1)
    .maybeSingle()

  if (apiKeyError) {
    throw new Error(apiKeyError.message)
  }

  return {
    tokensUsed: tokensUsedToday,
    tokenLimit: limit,
    hasUserOpenRouterKey: Boolean(apiKey),
    resetsAt: nextDayStart,
  }
}

export async function assertAppKeyUsageAllowed(feature: AiUsageFeature) {
  void feature

  const { tokensUsed, tokenLimit } = await getCurrentAiUsageStatus()

  if (tokensUsed >= tokenLimit) {
    throw new AiUsageLimitError(tokenLimit, tokensUsed)
  }
}

export async function recordAiUsage({
  feature,
  tokensUsed = null,
}: {
  feature: AiUsageFeature
  tokensUsed?: number | null
}) {
  const tokensToAdd =
    typeof tokensUsed === 'number' && Number.isFinite(tokensUsed)
      ? Math.max(0, Math.ceil(tokensUsed))
      : 0

  if (tokensToAdd === 0) {
    console.warn('OpenRouter response did not include token usage.')
    return
  }

  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()

  if (userError || !user) {
    return
  }

  const { dayStart, nextDayStart } = getUsageWindow()
  const { data, error: selectError } = await supabase
    .from('ai_usage')
    .select('id, tokens_used, created_at')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (selectError) {
    console.error('Failed to load AI usage row', selectError)
    return
  }

  const usageRow = data as AiUsageRow | null

  if (!usageRow) {
    const { error } = await supabase.from('ai_usage').insert({
      user_id: user.id,
      feature,
      tokens_used: tokensToAdd,
    })

    if (error) {
      console.error('Failed to create AI usage row', error)
    }

    return
  }

  const isCurrentRow = isInUsageWindow(
    usageRow.created_at,
    dayStart,
    nextDayStart,
  )
  const nextTokensUsed = isCurrentRow
    ? (usageRow.tokens_used ?? 0) + tokensToAdd
    : tokensToAdd

  const { error } = await supabase
    .from('ai_usage')
    .update({
      feature,
      tokens_used: nextTokensUsed,
      ...(isCurrentRow ? {} : { created_at: new Date().toISOString() }),
    })
    .eq('id', usageRow.id)

  if (error) {
    console.error('Failed to update AI usage row', error)
  }
}
